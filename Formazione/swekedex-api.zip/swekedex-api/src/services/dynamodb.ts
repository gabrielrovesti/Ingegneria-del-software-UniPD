// Create a service client module using ES6 syntax.
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DeleteCommand,
  DynamoDBDocumentClient,
  GetCommand,
  GetCommandInput,
  PutCommand,
  ScanCommand,
  ScanCommandInput,
} from "@aws-sdk/lib-dynamodb";
import { environment } from "src/environment/environment";
import { PokemonSpecies } from "src/types/PokemonSpecies";
import { UserData } from "src/types/UserData";

// Create an Amazon DynamoDB service client object.
export const ddbClient = new DynamoDBClient({ region: environment.awsRegion });

const marshallOptions = {
  // Whether to automatically convert empty strings, blobs, and sets to `null`.
  convertEmptyValues: true, // false, by default.
  // Whether to remove undefined values while marshalling.
  removeUndefinedValues: true, // false, by default.
  // Whether to convert typeof object to map attribute.
  convertClassInstanceToMap: false, // false, by default.
};

const unmarshallOptions = {
  // Whether to return numbers as a string instead of converting them to native JavaScript numbers.
  wrapNumbers: false, // false, by default.
};

// Create the DynamoDB document client.
const ddbDocClient = DynamoDBDocumentClient.from(ddbClient, {
  marshallOptions,
  unmarshallOptions,
});

const putPokemon = async (pokemon: PokemonSpecies) => {
  // Set the parameters.
  const params = {
    TableName: environment.dynamo.pokemonSpecies.tableName,
    Item: pokemon,
  };
  try {
    const data = await ddbDocClient.send(new PutCommand(params));
    console.log("Success - item added or updated", data);
  } catch (err) {
    console.log("Error", err.stack);
    throw err;
  }
};

const getPokemon = async (pokedexNumber: number) => {
  // Set the parameters.
  const params: GetCommandInput = {
    TableName: environment.dynamo.pokemonSpecies.tableName,
    Key: { pokedexNumber },
  };
  try {
    const data = await ddbDocClient.send(new GetCommand(params));
    console.log("Success - GET", data);
    return data.Item;
  } catch (err) {
    console.log("Error", err.stack);
    throw { err, pokedexNumber };
  }
};

const deletePokemon = async (pokedexNumber: number) => {
  // Set the parameters.
  const params: GetCommandInput = {
    TableName: environment.dynamo.pokemonSpecies.tableName,
    Key: { pokedexNumber },
  };
  try {
    const data = await ddbDocClient.send(new DeleteCommand(params));
    console.log("Success - GET", data);
  } catch (err) {
    console.log("Error", err.stack);
    throw { err, pokedexNumber };
  }
};

const getPokedex = async () => {
  // Set the parameters.
  const params: ScanCommandInput = {
    TableName: environment.dynamo.pokemonSpecies.tableName,
  };
  try {
    const data = await ddbDocClient.send(new ScanCommand(params));
    console.log("Success - GET", data);
    return data.Items.sort((a, b) => a.pokedexNumber - b.pokedexNumber);
  } catch (err) {
    console.log("Error", err.stack);
    throw { err };
  }
};

const putUserInfo = async (mail: string, userData: UserData) => {
  // Set the parameters.
  const params = {
    TableName: environment.dynamo.userData.tableName,
    Item: { mail, ...userData },
  };
  try {
    const data = await ddbDocClient.send(new PutCommand(params));
    console.log("Success - item added or updated", data);
  } catch (err) {
    console.log("Error", err.stack);
    throw err;
  }
};

const getUserInfo = async (mail: string): Promise<UserData> => {
  // Set the parameters.
  const params: GetCommandInput = {
    TableName: environment.dynamo.userData.tableName,
    Key: { mail },
  };
  try {
    const data = await ddbDocClient.send(new GetCommand(params));
    console.log("Success - GET", data);
    if (!data.Item) return { catchedPokedexNumbers: [] };
    const { mail, ...otherKeys } = data.Item;
    return otherKeys as UserData;
  } catch (err) {
    console.log("Error", err.stack);
    throw { err, mail };
  }
};

export {
  putPokemon,
  getPokemon,
  deletePokemon,
  getPokedex,
  putUserInfo,
  getUserInfo,
};
