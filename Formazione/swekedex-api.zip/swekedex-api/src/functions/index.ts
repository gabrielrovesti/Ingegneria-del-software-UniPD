export { default as pokedexGet } from "./pokemon/alldex/get";
export { default as pokemondelete } from "./pokemon/species/delete";
export { default as pokemonget } from "./pokemon/species/get";
export { default as pokemonput } from "./pokemon/species/put";
export { default as userdataGet } from "./userdata/get";
export { default as userdataPut } from "./userdata/put";
