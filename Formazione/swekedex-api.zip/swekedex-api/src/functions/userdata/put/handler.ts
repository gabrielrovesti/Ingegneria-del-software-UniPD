import { formatJSONResponse } from "@libs/api-gateway";
import { middyfy } from "@libs/lambda";
import { AuthAttributes, authorizer } from "src/middleware/validators";
import { putUserInfo } from "src/services/dynamodb";

const userdataPut = async (event) => {
  const { userMail }: AuthAttributes = event.attributes;
  const catchedPokedexNumbers: number[] = event.body.catchedPokedexNumbers;
  try {
    await putUserInfo(userMail, { catchedPokedexNumbers });
    return formatJSONResponse({}, 200);
  } catch (error) {
    return formatJSONResponse(
      {
        error,
      },
      400
    );
  }
};

export const main = authorizer(middyfy(userdataPut), ["viewer"]);
