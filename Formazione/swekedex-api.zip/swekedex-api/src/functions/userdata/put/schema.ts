export default {
  type: "object",
  properties: {
    catchedPokedexNumbers: { type: "array", items: { type: "number" } },
  },
  required: ["catchedPokedexNumbers"],
} as const;
