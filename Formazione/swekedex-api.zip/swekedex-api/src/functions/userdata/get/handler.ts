import { formatJSONResponse } from "@libs/api-gateway";
import { middyfy } from "@libs/lambda";
import { AuthAttributes, authorizer } from "src/middleware/validators";
import { getUserInfo } from "src/services/dynamodb";

const userdataGet = async (event) => {
  const { userMail }: AuthAttributes = event.attributes;
  try {
    const userData = await getUserInfo(userMail);
    return formatJSONResponse({ userData }, 200);
  } catch (error) {
    return formatJSONResponse(
      {
        error,
      },
      400
    );
  }
};

export const main = authorizer(middyfy(userdataGet), ["viewer"]);
