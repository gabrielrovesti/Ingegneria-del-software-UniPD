import { formatJSONResponse } from "@libs/api-gateway";
import { middyfy } from "@libs/lambda";
import { authorizer } from "src/middleware/validators";
import { getPokedex } from "src/services/dynamodb";

const pokemonGet = async (event) => {
  const pokedex = await getPokedex();
  return formatJSONResponse({ pokedex }, 200);
};

export const main = middyfy(authorizer(pokemonGet, ["admin", "viewer"]));
