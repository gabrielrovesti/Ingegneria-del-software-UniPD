import type { ValidatedEventAPIGatewayProxyEvent } from "@libs/api-gateway";
import { formatJSONResponse } from "@libs/api-gateway";
import { middyfy } from "@libs/lambda";
import { authorizer, pokedexNumberChecker } from "src/middleware/validators";
import { putPokemon } from "src/services/dynamodb";
import { PokemonSpecies } from "src/types/PokemonSpecies";
import { PokemonType } from "src/types/PokemonType";

import schema from "./schema";

const pokemonPut: ValidatedEventAPIGatewayProxyEvent<typeof schema> = async ({
  body,
  pathParameters,
  requestContext,
}) => {
  const pokedexNumber: number = pathParameters.pokedexNumber as any;
  const newPokemon: PokemonSpecies = {
    pokedexNumber,
    name: body.name,
    imageUrl: body.imageUrl,
    description: body.description,
    type1: body.type1 as PokemonType,
    type2: body.type2 as PokemonType,
    height: body.height,
    weigth: body.weigth,
    evolveFrom: body.evolveFrom,
  };

  try {
    await putPokemon(newPokemon);
  } catch (e) {
    return formatJSONResponse(
      {
        error: e,
      },
      500
    );
  }

  return formatJSONResponse(
    {
      newPokemon,
    },
    200
  );
};

export const main = middyfy(
  authorizer(pokedexNumberChecker<typeof schema>(pokemonPut), ["admin"])
);
