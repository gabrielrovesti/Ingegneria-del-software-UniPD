export default {
  type: "object",
  properties: {
    name: { type: "string" },
    imageUrl: { type: ["string", "null"] },
    description: { type: "string" },
    type1: { type: "string" },
    type2: { type: ["string", "null"] },
    height: { type: "number" },
    weigth: { type: "number" },
    evolveFrom: { type: ["number", "null"] },
  },
  required: [
    "name",
    "imageUrl",
    "description",
    "type1",
    "type2",
    "height",
    "weigth",
    "evolveFrom",
  ],
} as const;
