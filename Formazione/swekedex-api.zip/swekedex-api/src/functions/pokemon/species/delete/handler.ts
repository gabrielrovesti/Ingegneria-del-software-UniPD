import type { ValidatedEventAPIGatewayProxyEvent } from "@libs/api-gateway";
import { formatJSONResponse } from "@libs/api-gateway";
import { middyfy } from "@libs/lambda";
import { authorizer, pokedexNumberChecker } from "src/middleware/validators";
import { deletePokemon } from "src/services/dynamodb";

import schema from "./schema";

const pokemonDelete: ValidatedEventAPIGatewayProxyEvent<typeof schema> = async (
  event
) => {
  const pokedexNumber: number = event.pathParameters.pokedexNumber as any;

  try {
    await deletePokemon(pokedexNumber);
    return formatJSONResponse({}, 200);
  } catch (error) {
    return formatJSONResponse(
      {
        error,
      },
      400
    );
  }
};

export const main = middyfy(
  authorizer(pokedexNumberChecker<typeof schema>(pokemonDelete), ["admin"])
);
