import { formatJSONResponse } from "@libs/api-gateway";
import { middyfy } from "@libs/lambda";
import { authorizer, pokedexNumberChecker } from "src/middleware/validators";
import { getPokemon } from "src/services/dynamodb";

import schema from "./schema";

const pokemonGet = async (event) => {
  const pokedexNumber: number = event.pathParameters.pokedexNumber as any;

  try {
    const pokemon = await getPokemon(pokedexNumber);
    if (!pokemon.name) {
      return formatJSONResponse({}, 404);
    }
    return formatJSONResponse(
      {
        pokemon,
      },
      200
    );
  } catch (error) {
    return formatJSONResponse(
      {
        error,
      },
      400
    );
  }
};

export const main = middyfy(
  authorizer(pokedexNumberChecker<typeof schema>(pokemonGet), [
    "admin",
    "viewer",
  ])
);
