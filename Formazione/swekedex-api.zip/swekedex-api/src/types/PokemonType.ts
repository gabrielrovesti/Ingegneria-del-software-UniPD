const pokemonTypes = [
  "Normale",
  "Fuoco",
  "Lotta",
  "Acqua",
  "Volante",
  "Erba",
  "Veleno",
  "Elettro",
  "Terra",
  "Psico",
  "Roccia",
  "Ghiaccio",
  "Coleottero",
  "Drago",
  "Spettro",
  "Buio",
  "Acciaio",
  "Folletto",
  "Ombra",
] as const;

type PokemonType = typeof pokemonTypes[number];

export { PokemonType, pokemonTypes };
