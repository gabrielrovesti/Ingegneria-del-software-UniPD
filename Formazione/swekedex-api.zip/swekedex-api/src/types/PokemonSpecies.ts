import { PokemonType } from "./PokemonType";

interface PokemonSpecies {
  pokedexNumber: number;
  name: string;
  imageUrl: string | null;
  description: string;
  type1: PokemonType;
  type2: PokemonType | null;
  height: number;
  weigth: number;
  evolveFrom: number;
}

export { PokemonSpecies };
