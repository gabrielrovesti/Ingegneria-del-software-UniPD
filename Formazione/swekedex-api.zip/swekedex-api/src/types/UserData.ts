interface UserData {
  catchedPokedexNumbers: number[];
}

export { UserData };
