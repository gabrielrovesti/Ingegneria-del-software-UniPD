
// Inserisci le tue credenziali
module.exports={
	'USER_NAME':'postgres',
	'PASSWORD':'admin',
	'HOST':5400,
	'DB_NAME':'demoDatabase',
	'PORT':5000,
}//5432


