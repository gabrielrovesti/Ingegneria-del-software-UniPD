import Parameter from "./../Parameter"; 
	
export default class PcaParameter extends Parameter {}