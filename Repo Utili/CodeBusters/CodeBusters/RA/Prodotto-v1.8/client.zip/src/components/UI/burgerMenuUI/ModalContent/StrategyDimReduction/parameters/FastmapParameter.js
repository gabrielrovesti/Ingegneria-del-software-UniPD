import Parameter from "./../Parameter"; 
	
export default class FastmapParameter extends Parameter {}